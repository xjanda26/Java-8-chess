package ija.ija2018.homework2.game;

import ija.ija2018.homework2.common.Field;
import ija.ija2018.homework2.common.Figure;

/**
*
* @author xramos00
*/

public class HistoryMove {

	public Figure deleted=null;
	
	public Figure moved= null;
	
	public Field deletedFromField, movedFromField, movedToField;
	
	public Board b;
	
	public HistoryMove(Figure deleted, Field deletedFromField,Figure moved, Field movedFromField, Field movedToField, Board b) {
		
		this.deleted = deleted;
		this.moved = moved;
		this.deletedFromField = deletedFromField;
		this.movedFromField = movedFromField;
		this.movedToField = movedToField;
		this.b = b;
		
	}
	
}

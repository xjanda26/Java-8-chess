package ija.ija2018.homework2.view;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.input.MouseEvent;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Menu implements Initializable {

    @FXML private Button btnNewGame;

    @FXML private TabPane tabPane;
    @FXML private Tab tabNewGame;

    private SingleSelectionModel<Tab> selectionModel;
    private int gameCounter = 0;

    @Override
    public void initialize (URL location, ResourceBundle recources){
        btnNewGame.setOnMouseClicked(addTabNewGame);
        selectionModel = tabPane.getSelectionModel();
    }

    private EventHandler<MouseEvent> addTabNewGame = new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent event) {
            tabNewGame = new Tab();
            try {

                tabNewGame.setText("Hra " + ++gameCounter);
                tabNewGame.setClosable(true);
                tabNewGame.setId("newGame");

                tabNewGame.setContent(FXMLLoader.load(this.getClass().getResource("/ija/ija2018/homework2/view/newGameTab.fxml")));

                tabNewGame.setOnCloseRequest(new EventHandler<Event>()
                {
                    @Override
                    public void handle(Event arg0)
                    {
                        gameCounter--;
                    }
                });
            } catch (IOException e) {
                e.printStackTrace();
            }

            tabPane.getTabs().add(tabNewGame);
            NewGameTab.tabIndex = tabPane.getTabs().indexOf(tabNewGame);
            selectionModel.selectLast();
        }
    };






}

package ija.ija2018.homework2.game;

public class WrongMoveException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1617973048311228252L;
	
	public WrongMoveException(String errMsg) {
		super(errMsg);
	}
	
}
